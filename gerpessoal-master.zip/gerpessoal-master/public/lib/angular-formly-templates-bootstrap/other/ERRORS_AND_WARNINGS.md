Angular formly provides you with some handy warnings and errors to keep you from using it incorrectly. It will direct
you to these for additional help. If these don't help you, please reproduce the issue using
[this jsbin template](http://jsbin.com/biqesi/edit) and
[file an issue on GitHub](https://github.com/formly-js/angular-formly/issues) or
[join us on Gitter](https://gitter.im/formly-js/angular-formly).

