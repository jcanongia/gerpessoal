# CHANGELOG

The changelog is automatically updated using [semantic-release](https://github.com/semantic-release/semantic-release).
You can see it on the [releases page](https://github.com/formly-js/angular-formly/releases). (Shortcut:
[changelog.angular-formly.com](http://changelog.angular-formly.com))

